# Databricks notebook source
# MAGIC %run ../Includes/Classroom-Setup-05.2.2L

# COMMAND ----------

DA.data_factory.load()
